Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by alfredofreak ( https://www.freesound.org/people/alfredofreak/  )
You can find this pack online at: https://www.freesound.org/people/alfredofreak/packs/15358/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 250224__alfredofreak__controller-bluetooth-search-loop.wav
    * url: https://www.freesound.org/people/alfredofreak/sounds/250224/
    * license: Attribution
  * 250223__alfredofreak__tablet-standby-loop.wav
    * url: https://www.freesound.org/people/alfredofreak/sounds/250223/
    * license: Attribution
  * 250222__alfredofreak__phone-unlock.wav
    * url: https://www.freesound.org/people/alfredofreak/sounds/250222/
    * license: Attribution
  * 250221__alfredofreak__tablet-dismiss-notification.wav
    * url: https://www.freesound.org/people/alfredofreak/sounds/250221/
    * license: Attribution
  * 250220__alfredofreak__phone-off-clocksound-loop.wav
    * url: https://www.freesound.org/people/alfredofreak/sounds/250220/
    * license: Attribution
  * 250219__alfredofreak__phone-boot-up.wav
    * url: https://www.freesound.org/people/alfredofreak/sounds/250219/
    * license: Attribution
  * 250218__alfredofreak__desktop-sidefan-notsure-loop.wav
    * url: https://www.freesound.org/people/alfredofreak/sounds/250218/
    * license: Attribution
  * 250217__alfredofreak__hdd-laptop-spindown.wav
    * url: https://www.freesound.org/people/alfredofreak/sounds/250217/
    * license: Attribution
  * 250216__alfredofreak__hdd-laptop-spinup.wav
    * url: https://www.freesound.org/people/alfredofreak/sounds/250216/
    * license: Attribution
  * 250215__alfredofreak__phone-data-loop.wav
    * url: https://www.freesound.org/people/alfredofreak/sounds/250215/
    * license: Attribution
  * 250214__alfredofreak__hdd-external-folder-access-long.wav
    * url: https://www.freesound.org/people/alfredofreak/sounds/250214/
    * license: Attribution
  * 250213__alfredofreak__hdd-external-folder-access-short.wav
    * url: https://www.freesound.org/people/alfredofreak/sounds/250213/
    * license: Attribution
  * 250212__alfredofreak__hdd-external-spinup.wav
    * url: https://www.freesound.org/people/alfredofreak/sounds/250212/
    * license: Attribution
  * 250211__alfredofreak__laser-mouse-stationary-loop.wav
    * url: https://www.freesound.org/people/alfredofreak/sounds/250211/
    * license: Attribution

